<?php
/**
 * English language for syntaxhighlighter3 plugin
 *
 * @author Daniel Lindgren <bd.dali@gmail.com>
 */

$lang['theme'] = "CSS theme for SyntaxHiglighter 3";
$lang['brushes'] = "Available brushes for SyntaxHiglighter 3's autoloader. <br>Add new brush files to .../sxh3/scripts/, alias(es) and brush file name (space separated) to this comma-separated list.";