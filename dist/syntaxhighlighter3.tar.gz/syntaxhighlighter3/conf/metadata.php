<?php
/**
 * Options for the syntaxhighlighter3 plugin
 *
 * @author Daniel Lindgren <bd.dali@gmail.com>
 */
$meta['theme'] = array('multichoice','_choices' => array('shThemeDefault.css','shThemeEmacs.css','shThemeMidnight.css','shThemeDjango.css','shThemeFadeToGrey.css','shThemeRDark.css','shThemeEclipse.css','shThemeMDUltra.css'));
$meta['brushes'] = array('string');
