# Changelog

## 2016/06/12

* Allow ranges for highlight parameter
* Add .editorconfig
* Update README and several infos
* Add build tools
* Extract content of plugin in the repository
* Fork of Daniel Lindgren's syntaxhighlighter3 plugin
