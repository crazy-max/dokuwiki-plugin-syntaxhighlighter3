# Changelog

## 2016/06/12

* Update README and several infos
* Add build tools
* Extract content of plugin in the repository
* Fork of Daniel Lindgren's syntaxhighlighter3 plugin
